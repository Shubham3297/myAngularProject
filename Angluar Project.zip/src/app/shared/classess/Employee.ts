export interface Employee {
    id: number;
    name: string;
    post: string;
    salary: number;
    gender: string;
    address: string;
}