export interface User {
    id: number;
    user: string;
    passord: string;
}