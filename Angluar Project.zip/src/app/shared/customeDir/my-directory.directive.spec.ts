import { MyDirectoryDirective } from './my-directory.directive';

describe('MyDirectoryDirective', () => {
  it('should create an instance', () => {
    const directive = new MyDirectoryDirective();
    expect(directive).toBeTruthy();
  });
});
