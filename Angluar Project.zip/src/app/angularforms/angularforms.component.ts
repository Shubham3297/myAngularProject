import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angularforms',
  templateUrl: './angularforms.component.html',
  styleUrls: ['./angularforms.component.css']
})
export class AngularformsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
